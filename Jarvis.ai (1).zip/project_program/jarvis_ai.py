import json
import os
import urllib.request

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read_config():
    api_path = os.path.join(BASE_DIR, "jarvis_api.txt")
    api_key = ""
    base_url = "http://127.0.0.1:8787/v1"
    model = "jarvis-auto"
    if os.path.exists(api_path):
        with open(api_path, "r", encoding="utf-8") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                if s.startswith("ASTRA_JARVIS_API_KEY="):
                    api_key = s.split("=", 1)[1].strip()
                elif s.startswith("BASE_URL="):
                    base_url = s.split("=", 1)[1].strip()
                elif s.startswith("MODEL="):
                    model = s.split("=", 1)[1].strip()
                elif s.startswith("sk-jarvis-") and not api_key:
                    api_key = s
    sys_path = os.path.join(BASE_DIR, "jarvis_ai_system.txt")
    system_prompt = ""
    if os.path.exists(sys_path):
        with open(sys_path, "r", encoding="utf-8") as f:
            system_prompt = f.read().strip()
    return api_key, base_url.rstrip("/"), model, system_prompt


def ask_jarvis(user_message: str, history=None) -> str:
    api_key, base_url, model, system_prompt = _read_config()
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    if history:
        messages.extend(history)
    messages.append({"role": "user", "content": user_message})

    payload = json.dumps({
        "model": model,
        "messages": messages,
        "stream": False
    }).encode("utf-8")

    req = urllib.request.Request(
        f"{base_url}/chat/completions",
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]


def get_token_limits() -> dict:
    api_key, base_url, _, _ = _read_config()
    req = urllib.request.Request(
        f"{base_url}/usage",
        headers={"Authorization": f"Bearer {api_key}"},
        method="GET"
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


if __name__ == "__main__":
    print("Astra JARVIS AI подключён. Введите 'exit' для выхода.")
    while True:
        q = input("Вы: ").strip()
        if not q or q.lower() in ("exit", "quit"):
            break
        print("JARVIS:", ask_jarvis(q))