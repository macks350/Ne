const fs = require("fs");
const path = require("path");

function loadJarvisConfig() {
  const rootDir = path.resolve(__dirname, "..");
  const apiText = fs.readFileSync(path.join(rootDir, "jarvis_api.txt"), "utf-8");
  const systemPrompt = fs.readFileSync(path.join(rootDir, "jarvis_ai_system.txt"), "utf-8").trim();

  let apiKey = "";
  let baseUrl = "http://127.0.0.1:8787/v1";
  let model = "jarvis-auto";

  for (const rawLine of apiText.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    if (line.startsWith("ASTRA_JARVIS_API_KEY=")) apiKey = line.split("=")[1].trim();
    else if (line.startsWith("BASE_URL=")) baseUrl = line.split("=")[1].trim();
    else if (line.startsWith("MODEL=")) model = line.split("=")[1].trim();
  }
  return { apiKey, baseUrl: baseUrl.replace(/\/+$/, ""), model, systemPrompt };
}

async function askJarvis(prompt) {
  const cfg = loadJarvisConfig();
  const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${cfg.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: cfg.model,
      messages: [
        { role: "system", content: cfg.systemPrompt },
        { role: "user", content: prompt }
      ]
    })
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content || JSON.stringify(data);
}

module.exports = { loadJarvisConfig, askJarvis };